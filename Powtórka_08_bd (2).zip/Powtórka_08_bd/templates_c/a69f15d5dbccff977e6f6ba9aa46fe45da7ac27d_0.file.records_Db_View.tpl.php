<?php
/* Smarty version 4.1.0, created on 2022-04-25 23:53:38
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\Powtórka_07_routing\app\views\templates\records_Db_View.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62671862dd3359_60924478',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a69f15d5dbccff977e6f6ba9aa46fe45da7ac27d' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\Powtórka_07_routing\\app\\views\\templates\\records_Db_View.tpl',
      1 => 1650923581,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62671862dd3359_60924478 (Smarty_Internal_Template $_smarty_tpl) {
?><table>
<thead>
	<tr>
		<th>Kwota</th>
		<th>Lata</th>
		<th>Oprocentowanie %</th>
		<th>Rata miesięczna</th>
                <th>Data</th>
	
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 't');
$_smarty_tpl->tpl_vars['t']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['t']->value['kwota'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['czas'];?>
 </td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['oprocentowanie'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['result'];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['t']->value['data'];?>
</td></tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</tbody>
</table><?php }
}
