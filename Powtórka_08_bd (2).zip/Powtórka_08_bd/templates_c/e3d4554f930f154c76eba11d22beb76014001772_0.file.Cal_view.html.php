<?php
/* Smarty version 4.1.0, created on 2022-04-04 13:36:50
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\Powtórka_kontroler_główny\app\Cal_view.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_624ad852e5d978_55489582',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e3d4554f930f154c76eba11d22beb76014001772' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\Powtórka_kontroler_główny\\app\\Cal_view.html',
      1 => 1649072202,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_624ad852e5d978_55489582 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_536121562624ad852e38fb8_51139038', 'footer');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_538692356624ad852e3c441_02608200', 'content');
}
/* {block 'footer'} */
class Block_536121562624ad852e38fb8_51139038 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_536121562624ad852e38fb8_51139038',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Stopka!<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_538692356624ad852e3c441_02608200 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_538692356624ad852e3c441_02608200',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>



<div class="ogólny">	
	
    <form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/app/Cal.php" method="post">
<fieldset>
		<label for="kwota">Podaj kwote:</label>
                <input type="text" placeholder="kwota PLN" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value->kwota;?>
"  name ="kwota"/>
		
		<label for="czas">Podaj czas:</label>
                <input type="range"  min="3" max="48" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value->czas;?>
" name="czas"
		oninput="nextElementSibling.value = value"/>
		<output><?php echo $_smarty_tpl->tpl_vars['tab']->value->czas;?>
</output> miesiące
		
		<label for="oprocentowanie">Podaj oprocentowanie:</label>
                <input type="text"  placeholder="oprocentowanie %" value="<?php echo $_smarty_tpl->tpl_vars['tab']->value->oprocentowanie;?>
" name="oprocentowanie"/>
		
		
		
		
		
		<input type="submit"  value="Oblicz" class="pure-button-primary"/>
</fieldset>		
	
	</form>
	
<div  class="messages">
		
		
<?php if ($_smarty_tpl->tpl_vars['messages']->value->isError()) {?>
		<h4>Wystąpiły błędy: </h4>
		<ol class="err">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['messages']->value->getErrors(), 'err');
$_smarty_tpl->tpl_vars['err']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['err']->value) {
$_smarty_tpl->tpl_vars['err']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['err']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
		<br />
<?php }?>


<?php if ($_smarty_tpl->tpl_vars['messages']->value->isInfo()) {?>	
		<h4>Informacje: </h4>
		<ol class="inf">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['messages']->value->getInfos(), 'inf');
$_smarty_tpl->tpl_vars['inf']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['inf']->value) {
$_smarty_tpl->tpl_vars['inf']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['inf']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
<?php }?>


<?php if ((isset($_smarty_tpl->tpl_vars['result']->value->result))) {?>
	<h4>Wynik:</h4>
	<p class="res">
	Miesięczna rata:&emsp;<?php echo $_smarty_tpl->tpl_vars['result']->value->result;?>
 PLN
	</p>
	<br />
<?php }?>

</div>
</div>
	
	
<?php
}
}
/* {/block 'content'} */
}
