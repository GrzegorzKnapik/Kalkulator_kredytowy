<?php
/* Smarty version 4.1.0, created on 2022-05-09 00:00:58
  from 'C:\Users\Sony_PC\Desktop\XAMP\htdocs\Powtórka_08_bd\app\views\History_View_Db.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_62783d9ad79f23_61904492',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9c9c365958d16b586b83c02e106da7d773d1a533' => 
    array (
      0 => 'C:\\Users\\Sony_PC\\Desktop\\XAMP\\htdocs\\Powtórka_08_bd\\app\\views\\History_View_Db.tpl',
      1 => 1650923802,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:records_Db_View.tpl' => 1,
  ),
),false)) {
function content_62783d9ad79f23_61904492 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_175452141262783d9ad636d8_81814287', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl");
}
/* {block 'content'} */
class Block_175452141262783d9ad636d8_81814287 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_175452141262783d9ad636d8_81814287',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="pure-menu pure-menu-horizontal bottom-margin">
  <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
logout" class="pure-menu-heading pure-menu-link">Wyloguj</a>
        
  <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
calcCompute" class="pure-menu-heading pure-menu-link">Powrót do kalkulatora</a>
</div>        



       
        <h1> Historia: </h1>
                <?php $_smarty_tpl->_subTemplateRender('file:records_Db_View.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
             
<?php
}
}
/* {/block 'content'} */
}
